import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { AuthProvider, useAuth } from "@/contexts/AuthContext";
import { HerdProvider } from "@/contexts/HerdContext";
import { MilkProvider } from "@/contexts/MilkContext";
import { PastureProvider } from "@/contexts/PastureContext";
import { MovementProvider } from "@/contexts/MovementContext";
import { FinanceProvider } from "@/contexts/FinanceContext";
import { AppLayout } from "@/components/layout/AppLayout";
import Login from "./pages/Login";
import Signup from "./pages/Signup";
import Dashboard from "./pages/Dashboard";
import Herd from "./pages/Herd";
import MilkProduction from "./pages/MilkProduction";
import Pastures from "./pages/Pastures";
import Movements from "./pages/Movements";
import Finances from "./pages/Finances";
import NotFound from "./pages/NotFound";

function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { user, isLoading } = useAuth();
  if (isLoading) return null;
  if (!user) return <Navigate to="/login" replace />;
  return <>{children}</>;
}

function PublicRoute({ children }: { children: React.ReactNode }) {
  const { user, isLoading } = useAuth();
  if (isLoading) return null;
  if (user) return <Navigate to="/" replace />;
  return <>{children}</>;
}

const App = () => (
  <>
    <ToastContainer position="top-right" autoClose={3000} hideProgressBar newestOnTop />
    <BrowserRouter>
      <AuthProvider>
        <HerdProvider>
          <MilkProvider>
            <PastureProvider>
              <MovementProvider>
                <FinanceProvider>
                  <Routes>
                    <Route path="/login" element={<PublicRoute><Login /></PublicRoute>} />
                    <Route path="/signup" element={<PublicRoute><Signup /></PublicRoute>} />
                    <Route element={<ProtectedRoute><AppLayout /></ProtectedRoute>}>
                      <Route path="/" element={<Dashboard />} />
                      <Route path="/herd" element={<Herd />} />
                      <Route path="/milk" element={<MilkProduction />} />
                      <Route path="/pastures" element={<Pastures />} />
                      <Route path="/movements" element={<Movements />} />
                      <Route path="/finances" element={<Finances />} />
                    </Route>
                    <Route path="*" element={<NotFound />} />
                  </Routes>
                </FinanceProvider>
              </MovementProvider>
            </PastureProvider>
          </MilkProvider>
        </HerdProvider>
      </AuthProvider>
    </BrowserRouter>
  </>
);

export default App;
