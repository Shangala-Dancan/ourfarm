import { useLocation } from "react-router-dom";
import { useEffect } from "react";

const NotFound = () => {
  const location = useLocation();

  useEffect(() => {
    console.error("404 Error: User attempted to access non-existent route:", location.pathname);
  }, [location.pathname]);

  return (
    <div className="d-flex min-vh-100 align-items-center justify-content-center" style={{ backgroundColor: '#f5f7f5' }}>
      <div className="text-center">
        <h1 className="mb-3 display-1 fw-bold">404</h1>
        <p className="mb-3 h5 text-muted">Oops! Page not found</p>
        <a href="/" className="text-farmflow text-decoration-underline">Return to Home</a>
      </div>
    </div>
  );
};

export default NotFound;
