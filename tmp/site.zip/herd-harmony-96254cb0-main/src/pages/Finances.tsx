import { useState, useMemo } from "react";
import { Card, Button, Form, Row, Col, Table, Badge, Modal, Tab, Nav } from "react-bootstrap";
import { Plus, Trash2, DollarSign, TrendingUp, TrendingDown, BarChart3 } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend, PieChart, Pie, Cell } from "recharts";
import { useFinances, type FinanceRecord, type FinanceType, type FinanceCategory } from "@/contexts/FinanceContext";
import { toast } from "react-toastify";

const expenseCategories: { value: FinanceCategory; label: string }[] = [
  { value: "feed", label: "Feed" }, { value: "veterinary", label: "Veterinary" }, { value: "labor", label: "Labor" },
  { value: "equipment", label: "Equipment" }, { value: "maintenance", label: "Maintenance" }, { value: "other_expense", label: "Other" },
];
const incomeCategories: { value: FinanceCategory; label: string }[] = [
  { value: "milk_sales", label: "Milk Sales" }, { value: "animal_sales", label: "Animal Sales" }, { value: "other_income", label: "Other" },
];
const PIE_COLORS = ["#2d7a4f", "#3da066", "#6dc08c", "#4a90d9", "#e8943a", "#dc3545"];

function FinanceDialog({ open, onOpenChange, onSubmit }: {
  open: boolean; onOpenChange: (o: boolean) => void;
  onSubmit: (data: Omit<FinanceRecord, "id" | "farmId">) => void;
}) {
  const [form, setForm] = useState({ type: "expense" as FinanceType, category: "feed" as FinanceCategory, amount: "", date: new Date().toISOString().split("T")[0], description: "", notes: "" });
  const cats = form.type === "expense" ? expenseCategories : incomeCategories;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit({ ...form, amount: parseFloat(form.amount) || 0 });
    onOpenChange(false);
    setForm({ type: "expense", category: "feed", amount: "", date: new Date().toISOString().split("T")[0], description: "", notes: "" });
  };

  return (
    <Modal show={open} onHide={() => onOpenChange(false)} centered>
      <Modal.Header closeButton><Modal.Title>Add Transaction</Modal.Title></Modal.Header>
      <Form onSubmit={handleSubmit}>
        <Modal.Body>
          <Row className="g-3 mb-3">
            <Col sm={6}><Form.Group><Form.Label>Type</Form.Label>
              <Form.Select value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value as FinanceType, category: e.target.value === "expense" ? "feed" : "milk_sales" })}>
                <option value="expense">Expense</option><option value="income">Income</option>
              </Form.Select>
            </Form.Group></Col>
            <Col sm={6}><Form.Group><Form.Label>Category</Form.Label>
              <Form.Select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value as FinanceCategory })}>
                {cats.map((c) => <option key={c.value} value={c.value}>{c.label}</option>)}
              </Form.Select>
            </Form.Group></Col>
          </Row>
          <Row className="g-3 mb-3">
            <Col sm={6}><Form.Group><Form.Label>Amount ($) *</Form.Label><Form.Control type="number" step="0.01" required value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} /></Form.Group></Col>
            <Col sm={6}><Form.Group><Form.Label>Date *</Form.Label><Form.Control type="date" required value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} /></Form.Group></Col>
          </Row>
          <Form.Group><Form.Label>Description *</Form.Label><Form.Control required value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} /></Form.Group>
        </Modal.Body>
        <Modal.Footer><Button variant="secondary" onClick={() => onOpenChange(false)}>Cancel</Button><Button type="submit" className="btn-farmflow">Add Transaction</Button></Modal.Footer>
      </Form>
    </Modal>
  );
}

export default function Finances() {
  const { records, addRecord, deleteRecord } = useFinances();
  const [dialogOpen, setDialogOpen] = useState(false);

  const totalIncome = useMemo(() => records.filter((r) => r.type === "income").reduce((s, r) => s + r.amount, 0), [records]);
  const totalExpenses = useMemo(() => records.filter((r) => r.type === "expense").reduce((s, r) => s + r.amount, 0), [records]);
  const profit = totalIncome - totalExpenses;

  const monthlyData = useMemo(() => {
    const map: Record<string, { month: string; income: number; expense: number }> = {};
    records.forEach((r) => { const m = r.date.slice(0, 7); if (!map[m]) map[m] = { month: m, income: 0, expense: 0 }; if (r.type === "income") map[m].income += r.amount; else map[m].expense += r.amount; });
    return Object.values(map).sort((a, b) => a.month.localeCompare(b.month)).slice(-12).map((d) => ({ ...d, month: d.month.slice(2) }));
  }, [records]);

  const expenseByCategory = useMemo(() => {
    const map: Record<string, number> = {};
    records.filter((r) => r.type === "expense").forEach((r) => { map[r.category] = (map[r.category] || 0) + r.amount; });
    return Object.entries(map).map(([name, value]) => ({ name: name.replace("_", " "), value: Math.round(value) }));
  }, [records]);

  const allCategories = [...expenseCategories, ...incomeCategories];
  const getCatLabel = (v: string) => allCategories.find((c) => c.value === v)?.label || v;

  return (
    <div>
      <div className="d-flex justify-content-between align-items-center mb-4">
        <div><h1 className="h4 fw-bold">Financial Management</h1><p className="text-muted small mb-0">Track expenses, income, and generate financial reports</p></div>
        <Button className="btn-farmflow" onClick={() => setDialogOpen(true)}><Plus size={16} className="me-1" /> Add Transaction</Button>
      </div>

      <Row className="g-3 mb-4">
        <Col sm={6} lg={3}><Card><Card.Body className="d-flex align-items-center gap-3"><div className="stat-icon green"><TrendingUp size={20} /></div><div><h4 className="fw-bold mb-0">${totalIncome.toFixed(0)}</h4><small className="text-muted">Total Income</small></div></Card.Body></Card></Col>
        <Col sm={6} lg={3}><Card><Card.Body className="d-flex align-items-center gap-3"><div className="stat-icon red"><TrendingDown size={20} /></div><div><h4 className="fw-bold mb-0">${totalExpenses.toFixed(0)}</h4><small className="text-muted">Total Expenses</small></div></Card.Body></Card></Col>
        <Col sm={6} lg={3}><Card><Card.Body className="d-flex align-items-center gap-3"><div className={`stat-icon ${profit >= 0 ? 'green' : 'red'}`}><DollarSign size={20} /></div><div><h4 className="fw-bold mb-0">${profit.toFixed(0)}</h4><small className="text-muted">Net Profit</small></div></Card.Body></Card></Col>
        <Col sm={6} lg={3}><Card><Card.Body className="d-flex align-items-center gap-3"><div className="stat-icon green"><BarChart3 size={20} /></div><div><h4 className="fw-bold mb-0">{records.length}</h4><small className="text-muted">Transactions</small></div></Card.Body></Card></Col>
      </Row>

      <Tab.Container defaultActiveKey="records">
        <Nav variant="tabs" className="mb-3">
          <Nav.Item><Nav.Link eventKey="records">Transactions</Nav.Link></Nav.Item>
          <Nav.Item><Nav.Link eventKey="charts">Reports</Nav.Link></Nav.Item>
        </Nav>
        <Tab.Content>
          <Tab.Pane eventKey="records">
            <Card><Card.Body className="p-0">
              {records.length === 0 ? (
                <div className="p-5 text-center text-muted">No transactions yet.</div>
              ) : (
                <Table hover responsive className="mb-0">
                  <thead><tr><th>Date</th><th>Type</th><th>Category</th><th>Description</th><th className="text-end">Amount</th><th style={{ width: 40 }}></th></tr></thead>
                  <tbody>
                    {[...records].sort((a, b) => b.date.localeCompare(a.date)).map((r) => (
                      <tr key={r.id}>
                        <td className="small">{r.date}</td>
                        <td><Badge bg={r.type === "income" ? "success" : "secondary"} className="text-capitalize">{r.type}</Badge></td>
                        <td className="small text-capitalize">{getCatLabel(r.category)}</td>
                        <td className="small">{r.description}</td>
                        <td className={`text-end fw-medium ${r.type === "income" ? "text-success" : "text-danger"}`}>{r.type === "income" ? "+" : "-"}${r.amount.toFixed(2)}</td>
                        <td><Button variant="link" size="sm" className="p-0" onClick={() => { deleteRecord(r.id); toast.success("Transaction deleted"); }}><Trash2 size={14} className="text-danger" /></Button></td>
                      </tr>
                    ))}
                  </tbody>
                </Table>
              )}
            </Card.Body></Card>
          </Tab.Pane>
          <Tab.Pane eventKey="charts">
            <Card className="mb-3"><Card.Header className="bg-white fw-semibold">Monthly Revenue vs Expenses</Card.Header>
              <Card.Body style={{ height: 300 }}>
                {monthlyData.length === 0 ? <p className="text-muted small">No data to display.</p> : (
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={monthlyData}><CartesianGrid strokeDasharray="3 3" /><XAxis dataKey="month" fontSize={12} /><YAxis fontSize={12} /><Tooltip /><Legend /><Bar dataKey="income" fill="#2d7a4f" name="Income" radius={[4,4,0,0]} /><Bar dataKey="expense" fill="#dc3545" name="Expenses" radius={[4,4,0,0]} /></BarChart>
                  </ResponsiveContainer>
                )}
              </Card.Body>
            </Card>
            {expenseByCategory.length > 0 && (
              <Card><Card.Header className="bg-white fw-semibold">Expenses by Category</Card.Header>
                <Card.Body style={{ height: 300 }}>
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart><Pie data={expenseByCategory} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={100} label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}>{expenseByCategory.map((_, i) => <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />)}</Pie><Tooltip /></PieChart>
                  </ResponsiveContainer>
                </Card.Body>
              </Card>
            )}
          </Tab.Pane>
        </Tab.Content>
      </Tab.Container>

      <FinanceDialog open={dialogOpen} onOpenChange={setDialogOpen} onSubmit={(d) => { addRecord(d); toast.success("Transaction added"); }} />
    </div>
  );
}
