import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth, UserRole } from "@/contexts/AuthContext";
import { Card, Form, Button } from "react-bootstrap";
import { toast } from "react-toastify";
import { Tractor } from "lucide-react";

export default function Signup() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState<UserRole>("owner");
  const [loading, setLoading] = useState(false);
  const { signup } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      await signup(email, password, name, role);
      toast.success("Account created successfully!");
      navigate("/");
    } catch (err: any) {
      toast.error(err.message || "Signup failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-wrapper">
      <Card className="auth-card shadow-sm">
        <Card.Body className="p-4">
          <div className="text-center mb-4">
            <div className="auth-icon">
              <Tractor size={24} />
            </div>
            <h4 className="fw-bold mt-2">Create Account</h4>
            <p className="text-muted small">Start managing your livestock today</p>
          </div>
          <Form onSubmit={handleSubmit}>
            <Form.Group className="mb-3">
              <Form.Label>Full Name</Form.Label>
              <Form.Control placeholder="John Doe" value={name} onChange={(e) => setName(e.target.value)} required />
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label>Email</Form.Label>
              <Form.Control type="email" placeholder="you@example.com" value={email} onChange={(e) => setEmail(e.target.value)} required />
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label>Password</Form.Label>
              <Form.Control type="password" placeholder="••••••••" value={password} onChange={(e) => setPassword(e.target.value)} required minLength={6} />
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label>Role</Form.Label>
              <Form.Select value={role} onChange={(e) => setRole(e.target.value as UserRole)}>
                <option value="owner">Farm Owner</option>
                <option value="manager">Manager</option>
                <option value="worker">Worker</option>
              </Form.Select>
            </Form.Group>
            <Button type="submit" className="w-100 btn-farmflow" disabled={loading}>
              {loading ? "Creating account…" : "Create Account"}
            </Button>
            <p className="text-center text-muted small mt-3">
              Already have an account?{" "}
              <Link to="/login" className="text-farmflow fw-medium">Sign in</Link>
            </p>
          </Form>
        </Card.Body>
      </Card>
    </div>
  );
}
