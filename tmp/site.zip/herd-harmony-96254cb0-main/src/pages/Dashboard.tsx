import { useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { useHerd } from "@/contexts/HerdContext";
import { useMilk } from "@/contexts/MilkContext";
import { useMovements } from "@/contexts/MovementContext";
import { useFinances } from "@/contexts/FinanceContext";
import { Card, Button, Row, Col } from "react-bootstrap";
import { Bug as CowIcon, Milk, DollarSign, AlertTriangle, Plus, ArrowRight } from "lucide-react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, Legend } from "recharts";

export default function Dashboard() {
  const { currentFarm } = useAuth();
  const navigate = useNavigate();
  const { animals, healthRecords, breedingEvents } = useHerd();
  const { records: milkRecords } = useMilk();
  const { movements } = useMovements();
  const { records: financeRecords } = useFinances();

  const today = new Date().toISOString().split("T")[0];
  const thisMonth = today.slice(0, 7);

  const todayMilk = useMemo(() =>
    milkRecords.filter((r) => r.date === today).reduce((s, r) => s + r.yieldLiters, 0),
  [milkRecords, today]);

  const monthlyRevenue = useMemo(() =>
    financeRecords.filter((r) => r.type === "income" && r.date.startsWith(thisMonth)).reduce((s, r) => s + r.amount, 0),
  [financeRecords, thisMonth]);

  const monthlyExpenses = useMemo(() =>
    financeRecords.filter((r) => r.type === "expense" && r.date.startsWith(thisMonth)).reduce((s, r) => s + r.amount, 0),
  [financeRecords, thisMonth]);

  const pendingCalving = breedingEvents.filter((b) => b.outcome === "pending").length;
  const recentMovements = movements.filter((m) => m.date >= new Date(Date.now() - 7 * 86400000).toISOString().split("T")[0]).length;

  const milkTrend = useMemo(() => {
    const map: Record<string, number> = {};
    const cutoff = new Date(Date.now() - 14 * 86400000).toISOString().split("T")[0];
    milkRecords.filter((r) => r.date >= cutoff).forEach((r) => { map[r.date] = (map[r.date] || 0) + r.yieldLiters; });
    return Object.entries(map).sort(([a], [b]) => a.localeCompare(b)).map(([date, total]) => ({ date: date.slice(5), total: Math.round(total * 10) / 10 }));
  }, [milkRecords]);

  const financeTrend = useMemo(() => {
    const map: Record<string, { month: string; income: number; expense: number }> = {};
    financeRecords.forEach((r) => {
      const m = r.date.slice(0, 7);
      if (!map[m]) map[m] = { month: m, income: 0, expense: 0 };
      if (r.type === "income") map[m].income += r.amount; else map[m].expense += r.amount;
    });
    return Object.values(map).sort((a, b) => a.month.localeCompare(b.month)).slice(-6).map((d) => ({ ...d, month: d.month.slice(2) }));
  }, [financeRecords]);

  const recentActivity = useMemo(() => {
    const items: { date: string; text: string }[] = [];
    milkRecords.slice(-3).forEach((r) => items.push({ date: r.date, text: `Milk logged: ${r.yieldLiters}L` }));
    movements.slice(-3).forEach((m) => items.push({ date: m.date, text: `Movement: ${m.type} — ${m.reason || "no reason"}` }));
    financeRecords.slice(-3).forEach((f) => items.push({ date: f.date, text: `${f.type}: $${f.amount.toFixed(2)} — ${f.description}` }));
    healthRecords.slice(-3).forEach((h) => items.push({ date: h.date, text: `Health: ${h.type.replace("_", " ")} — ${h.description}` }));
    return items.sort((a, b) => b.date.localeCompare(a.date)).slice(0, 8);
  }, [milkRecords, movements, financeRecords, healthRecords]);

  const stats = [
    { label: "Total Herd", value: animals.length.toString(), icon: CowIcon, sub: `${animals.filter((a) => a.status === "active").length} active`, cls: "green" },
    { label: "Today's Milk", value: `${todayMilk.toFixed(1)}L`, icon: Milk, sub: `${milkRecords.length} total records`, cls: "green" },
    { label: "Pending Calving", value: pendingCalving.toString(), icon: AlertTriangle, sub: `${recentMovements} movements this week`, cls: "orange" },
    { label: "Monthly Revenue", value: `$${monthlyRevenue.toFixed(0)}`, icon: DollarSign, sub: `$${monthlyExpenses.toFixed(0)} expenses`, cls: "green" },
  ];

  return (
    <div>
      <div className="mb-4">
        <h1 className="h4 fw-bold">Dashboard</h1>
        <p className="text-muted small">Overview of {currentFarm?.name || "your farm"}</p>
      </div>

      <Row className="g-3 mb-4">
        {stats.map((stat) => (
          <Col sm={6} lg={3} key={stat.label}>
            <Card className="h-100">
              <Card.Body className="d-flex justify-content-between align-items-start">
                <div>
                  <p className="text-muted small mb-1">{stat.label}</p>
                  <h3 className="fw-bold mb-0">{stat.value}</h3>
                  <small className="text-muted">{stat.sub}</small>
                </div>
                <div className={`stat-icon ${stat.cls}`}>
                  <stat.icon size={18} style={{ color: 'var(--farmflow-green)' }} />
                </div>
              </Card.Body>
            </Card>
          </Col>
        ))}
      </Row>

      <Row className="g-3 mb-4">
        <Col lg={6}>
          <Card>
            <Card.Header className="d-flex justify-content-between align-items-center bg-white">
              <span className="fw-semibold">Milk Production (14 Days)</span>
              <Button variant="link" size="sm" className="text-farmflow p-0" onClick={() => navigate("/milk")}>View All <ArrowRight size={14} /></Button>
            </Card.Header>
            <Card.Body style={{ height: 220 }}>
              {milkTrend.length === 0 ? <p className="text-muted small">No production data yet.</p> : (
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={milkTrend}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" fontSize={11} />
                    <YAxis fontSize={11} />
                    <Tooltip />
                    <Line type="monotone" dataKey="total" stroke="#2d7a4f" strokeWidth={2} dot={false} />
                  </LineChart>
                </ResponsiveContainer>
              )}
            </Card.Body>
          </Card>
        </Col>
        <Col lg={6}>
          <Card>
            <Card.Header className="d-flex justify-content-between align-items-center bg-white">
              <span className="fw-semibold">Financial Overview</span>
              <Button variant="link" size="sm" className="text-farmflow p-0" onClick={() => navigate("/finances")}>View All <ArrowRight size={14} /></Button>
            </Card.Header>
            <Card.Body style={{ height: 220 }}>
              {financeTrend.length === 0 ? <p className="text-muted small">No financial data yet.</p> : (
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={financeTrend}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" fontSize={11} />
                    <YAxis fontSize={11} />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="income" fill="#2d7a4f" name="Income" radius={[3,3,0,0]} />
                    <Bar dataKey="expense" fill="#dc3545" name="Expenses" radius={[3,3,0,0]} />
                  </BarChart>
                </ResponsiveContainer>
              )}
            </Card.Body>
          </Card>
        </Col>
      </Row>

      <Row className="g-3">
        <Col lg={6}>
          <Card>
            <Card.Header className="bg-white"><span className="fw-semibold">Recent Activity</span></Card.Header>
            <Card.Body>
              {recentActivity.length === 0 ? (
                <p className="text-muted small">No activity yet. Start by adding animals to your herd.</p>
              ) : (
                <ul className="list-unstyled mb-0">
                  {recentActivity.map((item, i) => (
                    <li key={i} className="d-flex gap-2 small mb-2">
                      <span className="text-muted" style={{ minWidth: 70 }}>{item.date}</span>
                      <span>{item.text}</span>
                    </li>
                  ))}
                </ul>
              )}
            </Card.Body>
          </Card>
        </Col>
        <Col lg={6}>
          <Card>
            <Card.Header className="bg-white"><span className="fw-semibold">Quick Actions</span></Card.Header>
            <Card.Body>
              <Row className="g-2">
                <Col xs={6}><Button variant="outline-secondary" size="sm" className="w-100" onClick={() => navigate("/herd")}><Plus size={14} className="me-1" /> Add Animal</Button></Col>
                <Col xs={6}><Button variant="outline-secondary" size="sm" className="w-100" onClick={() => navigate("/milk")}><Plus size={14} className="me-1" /> Log Milk</Button></Col>
                <Col xs={6}><Button variant="outline-secondary" size="sm" className="w-100" onClick={() => navigate("/movements")}><Plus size={14} className="me-1" /> Log Movement</Button></Col>
                <Col xs={6}><Button variant="outline-secondary" size="sm" className="w-100" onClick={() => navigate("/finances")}><Plus size={14} className="me-1" /> Add Transaction</Button></Col>
              </Row>
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </div>
  );
}
