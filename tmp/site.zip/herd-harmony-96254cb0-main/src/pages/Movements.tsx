import { useState, useMemo } from "react";
import { Card, Button, Form, Row, Col, Table, Modal } from "react-bootstrap";
import { Plus, Trash2, ArrowRightLeft, LogIn, LogOut, AlertTriangle } from "lucide-react";
import { useMovements, type MovementRecord, type MovementType } from "@/contexts/MovementContext";
import { useHerd } from "@/contexts/HerdContext";
import { toast } from "react-toastify";

const typeIcons: Record<string, React.ReactNode> = {
  entry: <LogIn size={16} className="text-success" />,
  exit: <LogOut size={16} className="text-danger" />,
  transfer: <ArrowRightLeft size={16} className="text-primary" />,
};

function MovementDialog({ open, onOpenChange, animals, onSubmit }: {
  open: boolean; onOpenChange: (o: boolean) => void;
  animals: { id: string; tagNumber: string; name: string }[];
  onSubmit: (data: Omit<MovementRecord, "id" | "farmId">) => void;
}) {
  const [form, setForm] = useState({ animalId: "", type: "entry" as MovementType, date: new Date().toISOString().split("T")[0], reason: "", destination: "", source: "", notes: "" });
  const handleSubmit = (e: React.FormEvent) => { e.preventDefault(); onSubmit(form); onOpenChange(false); setForm({ animalId: "", type: "entry", date: new Date().toISOString().split("T")[0], reason: "", destination: "", source: "", notes: "" }); };
  return (
    <Modal show={open} onHide={() => onOpenChange(false)} centered>
      <Modal.Header closeButton><Modal.Title>Log Movement</Modal.Title></Modal.Header>
      <Form onSubmit={handleSubmit}>
        <Modal.Body>
          <Form.Group className="mb-3"><Form.Label>Animal *</Form.Label>
            <Form.Select value={form.animalId} onChange={(e) => setForm({ ...form, animalId: e.target.value })} required>
              <option value="">Select animal</option>
              {animals.map((a) => <option key={a.id} value={a.id}>{a.tagNumber} {a.name && `— ${a.name}`}</option>)}
            </Form.Select>
          </Form.Group>
          <Row className="g-3 mb-3">
            <Col sm={6}><Form.Group><Form.Label>Type *</Form.Label>
              <Form.Select value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value as MovementType })}>
                <option value="entry">Entry</option><option value="exit">Exit</option><option value="transfer">Transfer</option>
              </Form.Select>
            </Form.Group></Col>
            <Col sm={6}><Form.Group><Form.Label>Date *</Form.Label><Form.Control type="date" required value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} /></Form.Group></Col>
          </Row>
          <Form.Group className="mb-3"><Form.Label>Reason</Form.Label><Form.Control value={form.reason} onChange={(e) => setForm({ ...form, reason: e.target.value })} placeholder="e.g. Purchase, sale, pasture rotation" /></Form.Group>
          <Row className="g-3 mb-3">
            <Col sm={6}><Form.Group><Form.Label>Source</Form.Label><Form.Control value={form.source} onChange={(e) => setForm({ ...form, source: e.target.value })} /></Form.Group></Col>
            <Col sm={6}><Form.Group><Form.Label>Destination</Form.Label><Form.Control value={form.destination} onChange={(e) => setForm({ ...form, destination: e.target.value })} /></Form.Group></Col>
          </Row>
          <Form.Group><Form.Label>Notes</Form.Label><Form.Control as="textarea" rows={2} value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} /></Form.Group>
        </Modal.Body>
        <Modal.Footer><Button variant="secondary" onClick={() => onOpenChange(false)}>Cancel</Button><Button type="submit" className="btn-farmflow">Log Movement</Button></Modal.Footer>
      </Form>
    </Modal>
  );
}

export default function Movements() {
  const { movements, addMovement, deleteMovement } = useMovements();
  const { animals } = useHerd();
  const [dialogOpen, setDialogOpen] = useState(false);

  const animalMap = Object.fromEntries(animals.map((a) => [a.id, a]));

  const stats = useMemo(() => ({
    total: movements.length,
    entries: movements.filter((m) => m.type === "entry").length,
    exits: movements.filter((m) => m.type === "exit").length,
    thisMonth: movements.filter((m) => m.date.startsWith(new Date().toISOString().slice(0, 7))).length,
  }), [movements]);

  const alerts = useMemo(() => {
    const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString().split("T")[0];
    const recentAnimalIds = new Set(movements.filter((m) => m.date >= thirtyDaysAgo).map((m) => m.animalId));
    return animals.filter((a) => a.status === "active" && movements.some((m) => m.animalId === a.id) && !recentAnimalIds.has(a.id));
  }, [animals, movements]);

  return (
    <div>
      <div className="d-flex justify-content-between align-items-center mb-4">
        <div><h1 className="h4 fw-bold">Movement Monitoring</h1><p className="text-muted small mb-0">Track animal movements, entries, exits, and alerts</p></div>
        <Button className="btn-farmflow" onClick={() => setDialogOpen(true)}><Plus size={16} className="me-1" /> Log Movement</Button>
      </div>

      <Row className="g-3 mb-4">
        <Col sm={6} lg={3}><Card><Card.Body className="d-flex align-items-center gap-3"><div className="stat-icon green"><ArrowRightLeft size={20} /></div><div><h4 className="fw-bold mb-0">{stats.total}</h4><small className="text-muted">Total Movements</small></div></Card.Body></Card></Col>
        <Col sm={6} lg={3}><Card><Card.Body className="d-flex align-items-center gap-3"><div className="stat-icon green"><LogIn size={20} /></div><div><h4 className="fw-bold mb-0">{stats.entries}</h4><small className="text-muted">Entries</small></div></Card.Body></Card></Col>
        <Col sm={6} lg={3}><Card><Card.Body className="d-flex align-items-center gap-3"><div className="stat-icon red"><LogOut size={20} /></div><div><h4 className="fw-bold mb-0">{stats.exits}</h4><small className="text-muted">Exits</small></div></Card.Body></Card></Col>
        <Col sm={6} lg={3}><Card><Card.Body className="d-flex align-items-center gap-3"><div className="stat-icon green"><ArrowRightLeft size={20} /></div><div><h4 className="fw-bold mb-0">{stats.thisMonth}</h4><small className="text-muted">This Month</small></div></Card.Body></Card></Col>
      </Row>

      {alerts.length > 0 && (
        <Card className="border-danger mb-4">
          <Card.Body>
            <div className="d-flex align-items-center gap-2 mb-2"><AlertTriangle size={16} className="text-danger" /><span className="fw-medium small">Alerts</span></div>
            <ul className="list-unstyled small text-muted mb-0">
              {alerts.map((a) => <li key={a.id}>• {a.tagNumber} ({a.name || "unnamed"}) — no movement logged in 30+ days</li>)}
            </ul>
          </Card.Body>
        </Card>
      )}

      <Card><Card.Body className="p-0">
        {movements.length === 0 ? (
          <div className="p-5 text-center text-muted">No movements recorded yet.</div>
        ) : (
          <Table hover responsive className="mb-0">
            <thead><tr><th>Type</th><th>Date</th><th>Animal</th><th>Reason</th><th className="d-none d-md-table-cell">Source/Dest</th><th style={{ width: 40 }}></th></tr></thead>
            <tbody>
              {[...movements].sort((a, b) => b.date.localeCompare(a.date)).map((m) => (
                <tr key={m.id}>
                  <td>{typeIcons[m.type]}</td>
                  <td className="small">{m.date}</td>
                  <td>{animalMap[m.animalId]?.tagNumber || "—"}</td>
                  <td className="small">{m.reason || "—"}</td>
                  <td className="d-none d-md-table-cell small">{m.type === "exit" ? m.destination : m.source || "—"}</td>
                  <td><Button variant="link" size="sm" className="p-0" onClick={() => { deleteMovement(m.id); toast.success("Movement deleted"); }}><Trash2 size={14} className="text-danger" /></Button></td>
                </tr>
              ))}
            </tbody>
          </Table>
        )}
      </Card.Body></Card>

      <MovementDialog open={dialogOpen} onOpenChange={setDialogOpen} animals={animals} onSubmit={(d) => { addMovement(d); toast.success("Movement logged"); }} />
    </div>
  );
}
