import { useState, useMemo } from "react";
import { Card, Button, Form, Row, Col, Table, Badge, Modal, Tab, Nav } from "react-bootstrap";
import { Plus, Trash2, Milk, TrendingUp, Droplets } from "lucide-react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from "recharts";
import { useMilk, type MilkRecord } from "@/contexts/MilkContext";
import { useHerd } from "@/contexts/HerdContext";
import { toast } from "react-toastify";

function RecordDialog({ open, onOpenChange, animals, onSubmit }: {
  open: boolean; onOpenChange: (o: boolean) => void;
  animals: { id: string; tagNumber: string; name: string }[];
  onSubmit: (data: Omit<MilkRecord, "id" | "farmId">) => void;
}) {
  const [form, setForm] = useState({ animalId: "", date: new Date().toISOString().split("T")[0], session: "morning" as "morning" | "evening", yieldLiters: "", butterfatPercent: "", temperature: "", qualityNotes: "" });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit({ animalId: form.animalId, date: form.date, session: form.session, yieldLiters: parseFloat(form.yieldLiters) || 0, butterfatPercent: parseFloat(form.butterfatPercent) || 0, temperature: parseFloat(form.temperature) || 0, qualityNotes: form.qualityNotes });
    onOpenChange(false);
    setForm({ animalId: "", date: new Date().toISOString().split("T")[0], session: "morning", yieldLiters: "", butterfatPercent: "", temperature: "", qualityNotes: "" });
  };

  return (
    <Modal show={open} onHide={() => onOpenChange(false)} centered>
      <Modal.Header closeButton><Modal.Title>Log Milk Production</Modal.Title></Modal.Header>
      <Form onSubmit={handleSubmit}>
        <Modal.Body>
          <Form.Group className="mb-3"><Form.Label>Animal *</Form.Label>
            <Form.Select value={form.animalId} onChange={(e) => setForm({ ...form, animalId: e.target.value })} required>
              <option value="">Select animal</option>
              {animals.map((a) => <option key={a.id} value={a.id}>{a.tagNumber} {a.name && `— ${a.name}`}</option>)}
            </Form.Select>
          </Form.Group>
          <Row className="g-3 mb-3">
            <Col sm={6}><Form.Group><Form.Label>Date *</Form.Label><Form.Control type="date" required value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} /></Form.Group></Col>
            <Col sm={6}><Form.Group><Form.Label>Session</Form.Label>
              <Form.Select value={form.session} onChange={(e) => setForm({ ...form, session: e.target.value as "morning" | "evening" })}>
                <option value="morning">Morning</option><option value="evening">Evening</option>
              </Form.Select>
            </Form.Group></Col>
          </Row>
          <Row className="g-3 mb-3">
            <Col sm={4}><Form.Group><Form.Label>Yield (L) *</Form.Label><Form.Control type="number" step="0.1" required value={form.yieldLiters} onChange={(e) => setForm({ ...form, yieldLiters: e.target.value })} /></Form.Group></Col>
            <Col sm={4}><Form.Group><Form.Label>Butterfat %</Form.Label><Form.Control type="number" step="0.1" value={form.butterfatPercent} onChange={(e) => setForm({ ...form, butterfatPercent: e.target.value })} /></Form.Group></Col>
            <Col sm={4}><Form.Group><Form.Label>Temp (°C)</Form.Label><Form.Control type="number" step="0.1" value={form.temperature} onChange={(e) => setForm({ ...form, temperature: e.target.value })} /></Form.Group></Col>
          </Row>
          <Form.Group><Form.Label>Quality Notes</Form.Label><Form.Control value={form.qualityNotes} onChange={(e) => setForm({ ...form, qualityNotes: e.target.value })} /></Form.Group>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button type="submit" className="btn-farmflow">Log Production</Button>
        </Modal.Footer>
      </Form>
    </Modal>
  );
}

export default function MilkProduction() {
  const { records, addRecord, deleteRecord } = useMilk();
  const { animals } = useHerd();
  const [dialogOpen, setDialogOpen] = useState(false);

  const femaleAnimals = animals.filter((a) => a.gender === "female" && a.status === "active");
  const animalMap = Object.fromEntries(animals.map((a) => [a.id, a]));

  const todayTotal = useMemo(() => {
    const today = new Date().toISOString().split("T")[0];
    return records.filter((r) => r.date === today).reduce((s, r) => s + r.yieldLiters, 0);
  }, [records]);

  const avgButterfat = useMemo(() => {
    const withBf = records.filter((r) => r.butterfatPercent > 0);
    return withBf.length ? (withBf.reduce((s, r) => s + r.butterfatPercent, 0) / withBf.length).toFixed(1) : "—";
  }, [records]);

  const dailyData = useMemo(() => {
    const map: Record<string, number> = {};
    records.forEach((r) => { map[r.date] = (map[r.date] || 0) + r.yieldLiters; });
    return Object.entries(map).sort(([a], [b]) => a.localeCompare(b)).slice(-30).map(([date, total]) => ({ date: date.slice(5), total: Math.round(total * 10) / 10 }));
  }, [records]);

  const perAnimalData = useMemo(() => {
    const map: Record<string, { name: string; total: number; count: number }> = {};
    records.forEach((r) => {
      if (!map[r.animalId]) map[r.animalId] = { name: animalMap[r.animalId]?.name || animalMap[r.animalId]?.tagNumber || r.animalId.slice(0, 6), total: 0, count: 0 };
      map[r.animalId].total += r.yieldLiters; map[r.animalId].count++;
    });
    return Object.values(map).map((v) => ({ name: v.name, avg: Math.round((v.total / v.count) * 10) / 10 })).sort((a, b) => b.avg - a.avg).slice(0, 10);
  }, [records, animalMap]);

  return (
    <div>
      <div className="d-flex justify-content-between align-items-center mb-4">
        <div><h1 className="h4 fw-bold">Milk Production</h1><p className="text-muted small mb-0">Track daily yields, quality checks, and production trends</p></div>
        <Button className="btn-farmflow" onClick={() => setDialogOpen(true)}><Plus size={16} className="me-1" /> Log Production</Button>
      </div>

      <Row className="g-3 mb-4">
        {[
          { icon: Milk, value: records.length, label: "Total Records" },
          { icon: Droplets, value: `${todayTotal.toFixed(1)}L`, label: "Today's Yield" },
          { icon: TrendingUp, value: `${avgButterfat}%`, label: "Avg Butterfat" },
          { icon: Milk, value: `${records.reduce((s, r) => s + r.yieldLiters, 0).toFixed(0)}L`, label: "Total Production" },
        ].map((s, i) => (
          <Col sm={6} lg={3} key={i}>
            <Card><Card.Body className="d-flex align-items-center gap-3">
              <div className="stat-icon green"><s.icon size={20} /></div>
              <div><h4 className="fw-bold mb-0">{s.value}</h4><small className="text-muted">{s.label}</small></div>
            </Card.Body></Card>
          </Col>
        ))}
      </Row>

      <Tab.Container defaultActiveKey="records">
        <Nav variant="tabs" className="mb-3">
          <Nav.Item><Nav.Link eventKey="records">Records</Nav.Link></Nav.Item>
          <Nav.Item><Nav.Link eventKey="trends">Trends</Nav.Link></Nav.Item>
          <Nav.Item><Nav.Link eventKey="per-animal">Per Animal</Nav.Link></Nav.Item>
        </Nav>
        <Tab.Content>
          <Tab.Pane eventKey="records">
            <Card><Card.Body className="p-0">
              {records.length === 0 ? (
                <div className="p-5 text-center text-muted">No production records yet. Log your first milking session.</div>
              ) : (
                <Table hover responsive className="mb-0">
                  <thead><tr><th>Date</th><th>Animal</th><th>Session</th><th>Yield (L)</th><th className="d-none d-md-table-cell">Fat %</th><th className="d-none d-md-table-cell">Temp</th><th style={{ width: 40 }}></th></tr></thead>
                  <tbody>
                    {[...records].sort((a, b) => b.date.localeCompare(a.date)).map((r) => (
                      <tr key={r.id}>
                        <td className="small">{r.date}</td>
                        <td>{animalMap[r.animalId]?.tagNumber || "—"}</td>
                        <td><Badge bg="light" text="dark" className="text-capitalize">{r.session}</Badge></td>
                        <td className="fw-medium">{r.yieldLiters}L</td>
                        <td className="d-none d-md-table-cell">{r.butterfatPercent || "—"}</td>
                        <td className="d-none d-md-table-cell">{r.temperature ? `${r.temperature}°C` : "—"}</td>
                        <td><Button variant="link" size="sm" className="p-0" onClick={() => { deleteRecord(r.id); toast.success("Record deleted"); }}><Trash2 size={14} className="text-danger" /></Button></td>
                      </tr>
                    ))}
                  </tbody>
                </Table>
              )}
            </Card.Body></Card>
          </Tab.Pane>
          <Tab.Pane eventKey="trends">
            <Card><Card.Header className="bg-white fw-semibold">Daily Production (Last 30 Days)</Card.Header>
              <Card.Body style={{ height: 300 }}>
                {dailyData.length === 0 ? <p className="text-muted small">No data to display.</p> : (
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={dailyData}><CartesianGrid strokeDasharray="3 3" /><XAxis dataKey="date" fontSize={12} /><YAxis fontSize={12} /><Tooltip /><Line type="monotone" dataKey="total" stroke="#2d7a4f" strokeWidth={2} dot={false} /></LineChart>
                  </ResponsiveContainer>
                )}
              </Card.Body>
            </Card>
          </Tab.Pane>
          <Tab.Pane eventKey="per-animal">
            <Card><Card.Header className="bg-white fw-semibold">Average Yield per Animal</Card.Header>
              <Card.Body style={{ height: 300 }}>
                {perAnimalData.length === 0 ? <p className="text-muted small">No data to display.</p> : (
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={perAnimalData}><CartesianGrid strokeDasharray="3 3" /><XAxis dataKey="name" fontSize={12} /><YAxis fontSize={12} /><Tooltip /><Bar dataKey="avg" fill="#2d7a4f" radius={[4,4,0,0]} /></BarChart>
                  </ResponsiveContainer>
                )}
              </Card.Body>
            </Card>
          </Tab.Pane>
        </Tab.Content>
      </Tab.Container>

      <RecordDialog open={dialogOpen} onOpenChange={setDialogOpen} animals={femaleAnimals} onSubmit={(d) => { addRecord(d); toast.success(`${d.yieldLiters}L recorded.`); }} />
    </div>
  );
}
