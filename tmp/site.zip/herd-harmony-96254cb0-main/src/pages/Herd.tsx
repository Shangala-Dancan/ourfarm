import { useState, useMemo } from "react";
import { Card, Button, Form, Row, Col, Table, Badge, InputGroup } from "react-bootstrap";
import { Plus, Search, PawPrint, Heart, Baby } from "lucide-react";
import { useHerd, type Animal } from "@/contexts/HerdContext";
import { AnimalFormDialog } from "@/components/herd/AnimalFormDialog";
import { AnimalDetailSheet } from "@/components/herd/AnimalDetailSheet";
import { toast } from "react-toastify";

const statusBadge: Record<string, string> = {
  active: "badge-active",
  sold: "badge-sold",
  deceased: "badge-deceased",
};

export default function Herd() {
  const { animals, healthRecords, breedingEvents, addAnimal, updateAnimal, deleteAnimal } = useHerd();

  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [genderFilter, setGenderFilter] = useState("all");
  const [formOpen, setFormOpen] = useState(false);
  const [editAnimal, setEditAnimal] = useState<Animal | null>(null);
  const [detailAnimal, setDetailAnimal] = useState<Animal | null>(null);
  const [detailOpen, setDetailOpen] = useState(false);

  const filtered = useMemo(() => {
    return animals.filter((a) => {
      const matchesSearch = a.name.toLowerCase().includes(search.toLowerCase()) || a.tagNumber.toLowerCase().includes(search.toLowerCase()) || a.breed.toLowerCase().includes(search.toLowerCase());
      const matchesStatus = statusFilter === "all" || a.status === statusFilter;
      const matchesGender = genderFilter === "all" || a.gender === genderFilter;
      return matchesSearch && matchesStatus && matchesGender;
    });
  }, [animals, search, statusFilter, genderFilter]);

  const stats = useMemo(() => ({
    total: animals.length,
    active: animals.filter((a) => a.status === "active").length,
    healthRecords: healthRecords.length,
    pendingBreeding: breedingEvents.filter((b) => b.outcome === "pending").length,
  }), [animals, healthRecords, breedingEvents]);

  const handleAdd = (data: Omit<Animal, "id" | "farmId">) => {
    addAnimal(data);
    toast.success(`${data.name || data.tagNumber} registered.`);
  };

  const handleEdit = (data: Omit<Animal, "id" | "farmId">) => {
    if (editAnimal) {
      updateAnimal(editAnimal.id, data);
      toast.success("Animal updated");
      setEditAnimal(null);
    }
  };

  const handleDelete = (animal: Animal) => {
    deleteAnimal(animal.id);
    toast.success(`${animal.name || animal.tagNumber} deleted.`);
  };

  return (
    <div>
      <div className="d-flex justify-content-between align-items-center mb-4">
        <div>
          <h1 className="h4 fw-bold">Herd Management</h1>
          <p className="text-muted small mb-0">Manage your animal registry, health records, and breeding</p>
        </div>
        <Button className="btn-farmflow" onClick={() => { setEditAnimal(null); setFormOpen(true); }}>
          <Plus size={16} className="me-1" /> Add Animal
        </Button>
      </div>

      <Row className="g-3 mb-4">
        {[
          { icon: PawPrint, value: stats.total, label: "Total Animals", cls: "green" },
          { icon: PawPrint, value: stats.active, label: "Active", cls: "green" },
          { icon: Heart, value: stats.healthRecords, label: "Health Records", cls: "blue" },
          { icon: Baby, value: stats.pendingBreeding, label: "Pending Calving", cls: "orange" },
        ].map((s, i) => (
          <Col sm={6} lg={3} key={i}>
            <Card>
              <Card.Body className="d-flex align-items-center gap-3">
                <div className={`stat-icon ${s.cls}`}><s.icon size={20} /></div>
                <div><h4 className="fw-bold mb-0">{s.value}</h4><small className="text-muted">{s.label}</small></div>
              </Card.Body>
            </Card>
          </Col>
        ))}
      </Row>

      <Row className="g-2 mb-3">
        <Col sm>
          <InputGroup>
            <InputGroup.Text><Search size={16} /></InputGroup.Text>
            <Form.Control placeholder="Search by name, tag, or breed..." value={search} onChange={(e) => setSearch(e.target.value)} />
          </InputGroup>
        </Col>
        <Col sm="auto">
          <Form.Select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}>
            <option value="all">All Status</option>
            <option value="active">Active</option>
            <option value="sold">Sold</option>
            <option value="deceased">Deceased</option>
          </Form.Select>
        </Col>
        <Col sm="auto">
          <Form.Select value={genderFilter} onChange={(e) => setGenderFilter(e.target.value)}>
            <option value="all">All Gender</option>
            <option value="female">Female</option>
            <option value="male">Male</option>
          </Form.Select>
        </Col>
      </Row>

      <Card>
        <Card.Body className="p-0">
          {filtered.length === 0 ? (
            <div className="p-5 text-center text-muted">
              {animals.length === 0 ? 'No animals registered yet. Click "Add Animal" to get started.' : "No animals match your filters."}
            </div>
          ) : (
            <Table hover responsive className="mb-0 table-clickable">
              <thead>
                <tr>
                  <th>Tag</th>
                  <th>Name</th>
                  <th className="d-none d-md-table-cell">Breed</th>
                  <th className="d-none d-sm-table-cell">Gender</th>
                  <th>Status</th>
                  <th className="d-none d-lg-table-cell">DOB</th>
                  <th style={{ width: 80 }}></th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((animal) => (
                  <tr key={animal.id} onClick={() => { setDetailAnimal(animal); setDetailOpen(true); }}>
                    <td className="fw-medium">{animal.tagNumber}</td>
                    <td>{animal.name || "—"}</td>
                    <td className="d-none d-md-table-cell">{animal.breed || "—"}</td>
                    <td className="d-none d-sm-table-cell text-capitalize">{animal.gender}</td>
                    <td><Badge className={`${statusBadge[animal.status]} text-capitalize`}>{animal.status}</Badge></td>
                    <td className="d-none d-lg-table-cell small">{animal.dateOfBirth || "—"}</td>
                    <td>
                      <Button variant="link" size="sm" className="text-danger p-0" onClick={(e) => { e.stopPropagation(); handleDelete(animal); }}>
                        Delete
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </Table>
          )}
        </Card.Body>
      </Card>

      <AnimalFormDialog
        open={formOpen || !!editAnimal}
        onOpenChange={(open) => { if (!open) { setFormOpen(false); setEditAnimal(null); } }}
        animal={editAnimal}
        onSubmit={editAnimal ? handleEdit : handleAdd}
      />
      <AnimalDetailSheet
        animal={detailAnimal}
        open={detailOpen}
        onOpenChange={setDetailOpen}
        onEdit={(a) => { setDetailOpen(false); setEditAnimal(a); setFormOpen(true); }}
      />
    </div>
  );
}
