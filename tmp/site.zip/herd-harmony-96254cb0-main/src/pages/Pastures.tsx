import { useState, useMemo } from "react";
import { Card, Button, Form, Row, Col, Table, Badge, Modal, Tab, Nav } from "react-bootstrap";
import { Plus, Trash2, TreePine, MapPin, CalendarDays } from "lucide-react";
import { usePastures, type Pasture, type PastureCondition, type RotationEntry } from "@/contexts/PastureContext";
import { toast } from "react-toastify";

const conditionBadge: Record<string, string> = { good: "badge-good", fair: "badge-fair", poor: "badge-poor" };

function PastureDialog({ open, onOpenChange, onSubmit }: {
  open: boolean; onOpenChange: (o: boolean) => void;
  onSubmit: (data: Omit<Pasture, "id" | "farmId">) => void;
}) {
  const [form, setForm] = useState({ name: "", sizeAcres: "", grassType: "", condition: "good" as PastureCondition, currentHerdCount: "0", isResting: false, notes: "" });
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit({ name: form.name, sizeAcres: parseFloat(form.sizeAcres) || 0, grassType: form.grassType, condition: form.condition, currentHerdCount: parseInt(form.currentHerdCount) || 0, isResting: form.isResting, notes: form.notes });
    onOpenChange(false);
    setForm({ name: "", sizeAcres: "", grassType: "", condition: "good", currentHerdCount: "0", isResting: false, notes: "" });
  };
  return (
    <Modal show={open} onHide={() => onOpenChange(false)} centered>
      <Modal.Header closeButton><Modal.Title>Add Pasture</Modal.Title></Modal.Header>
      <Form onSubmit={handleSubmit}>
        <Modal.Body>
          <Row className="g-3 mb-3">
            <Col sm={6}><Form.Group><Form.Label>Name *</Form.Label><Form.Control required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></Form.Group></Col>
            <Col sm={6}><Form.Group><Form.Label>Size (acres)</Form.Label><Form.Control type="number" step="0.1" value={form.sizeAcres} onChange={(e) => setForm({ ...form, sizeAcres: e.target.value })} /></Form.Group></Col>
          </Row>
          <Row className="g-3 mb-3">
            <Col sm={6}><Form.Group><Form.Label>Grass Type</Form.Label><Form.Control value={form.grassType} onChange={(e) => setForm({ ...form, grassType: e.target.value })} /></Form.Group></Col>
            <Col sm={6}><Form.Group><Form.Label>Condition</Form.Label>
              <Form.Select value={form.condition} onChange={(e) => setForm({ ...form, condition: e.target.value as PastureCondition })}>
                <option value="good">Good</option><option value="fair">Fair</option><option value="poor">Poor</option>
              </Form.Select>
            </Form.Group></Col>
          </Row>
          <Form.Check type="switch" label="Currently Resting" checked={form.isResting} onChange={(e) => setForm({ ...form, isResting: e.target.checked })} className="mb-3" />
          <Form.Group><Form.Label>Notes</Form.Label><Form.Control as="textarea" rows={2} value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} /></Form.Group>
        </Modal.Body>
        <Modal.Footer><Button variant="secondary" onClick={() => onOpenChange(false)}>Cancel</Button><Button type="submit" className="btn-farmflow">Add Pasture</Button></Modal.Footer>
      </Form>
    </Modal>
  );
}

function RotationDialog({ open, onOpenChange, pastures, onSubmit }: {
  open: boolean; onOpenChange: (o: boolean) => void;
  pastures: Pasture[]; onSubmit: (data: Omit<RotationEntry, "id" | "farmId">) => void;
}) {
  const [form, setForm] = useState({ pastureId: "", startDate: "", endDate: "", herdGroup: "" });
  const handleSubmit = (e: React.FormEvent) => { e.preventDefault(); onSubmit(form); onOpenChange(false); setForm({ pastureId: "", startDate: "", endDate: "", herdGroup: "" }); };
  return (
    <Modal show={open} onHide={() => onOpenChange(false)} centered>
      <Modal.Header closeButton><Modal.Title>Add Rotation</Modal.Title></Modal.Header>
      <Form onSubmit={handleSubmit}>
        <Modal.Body>
          <Form.Group className="mb-3"><Form.Label>Pasture *</Form.Label>
            <Form.Select value={form.pastureId} onChange={(e) => setForm({ ...form, pastureId: e.target.value })} required>
              <option value="">Select pasture</option>
              {pastures.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
            </Form.Select>
          </Form.Group>
          <Row className="g-3 mb-3">
            <Col sm={6}><Form.Group><Form.Label>Start Date *</Form.Label><Form.Control type="date" required value={form.startDate} onChange={(e) => setForm({ ...form, startDate: e.target.value })} /></Form.Group></Col>
            <Col sm={6}><Form.Group><Form.Label>End Date *</Form.Label><Form.Control type="date" required value={form.endDate} onChange={(e) => setForm({ ...form, endDate: e.target.value })} /></Form.Group></Col>
          </Row>
          <Form.Group><Form.Label>Herd Group *</Form.Label><Form.Control required value={form.herdGroup} onChange={(e) => setForm({ ...form, herdGroup: e.target.value })} placeholder="e.g. Dairy Herd A" /></Form.Group>
        </Modal.Body>
        <Modal.Footer><Button variant="secondary" onClick={() => onOpenChange(false)}>Cancel</Button><Button type="submit" className="btn-farmflow">Add Rotation</Button></Modal.Footer>
      </Form>
    </Modal>
  );
}

export default function Pastures() {
  const { pastures, rotations, addPasture, deletePasture, addRotation, deleteRotation } = usePastures();
  const [pastureOpen, setPastureOpen] = useState(false);
  const [rotationOpen, setRotationOpen] = useState(false);

  const stats = useMemo(() => ({
    total: pastures.length,
    totalAcres: pastures.reduce((s, p) => s + p.sizeAcres, 0),
    resting: pastures.filter((p) => p.isResting).length,
    poor: pastures.filter((p) => p.condition === "poor").length,
  }), [pastures]);

  return (
    <div>
      <div className="d-flex justify-content-between align-items-center mb-4">
        <div><h1 className="h4 fw-bold">Pasture Management</h1><p className="text-muted small mb-0">Manage pastures, rotation schedules, and utilization</p></div>
        <div className="d-flex gap-2">
          <Button variant="outline-secondary" onClick={() => setRotationOpen(true)}><CalendarDays size={16} className="me-1" /> Add Rotation</Button>
          <Button className="btn-farmflow" onClick={() => setPastureOpen(true)}><Plus size={16} className="me-1" /> Add Pasture</Button>
        </div>
      </div>

      <Row className="g-3 mb-4">
        {[
          { icon: TreePine, value: stats.total, label: "Pastures", cls: "green" },
          { icon: MapPin, value: stats.totalAcres.toFixed(1), label: "Total Acres", cls: "green" },
          { icon: TreePine, value: stats.resting, label: "Resting", cls: "green" },
          { icon: TreePine, value: stats.poor, label: "Poor Condition", cls: "red" },
        ].map((s, i) => (
          <Col sm={6} lg={3} key={i}><Card><Card.Body className="d-flex align-items-center gap-3"><div className={`stat-icon ${s.cls}`}><s.icon size={20} /></div><div><h4 className="fw-bold mb-0">{s.value}</h4><small className="text-muted">{s.label}</small></div></Card.Body></Card></Col>
        ))}
      </Row>

      <Tab.Container defaultActiveKey="overview">
        <Nav variant="tabs" className="mb-3">
          <Nav.Item><Nav.Link eventKey="overview">Pastures</Nav.Link></Nav.Item>
          <Nav.Item><Nav.Link eventKey="rotations">Rotation Schedule ({rotations.length})</Nav.Link></Nav.Item>
        </Nav>
        <Tab.Content>
          <Tab.Pane eventKey="overview">
            {pastures.length === 0 ? (
              <Card><Card.Body className="p-5 text-center text-muted">No pastures registered yet. Add your first pasture.</Card.Body></Card>
            ) : (
              <Row className="g-3">
                {pastures.map((p) => (
                  <Col sm={6} lg={4} key={p.id}>
                    <Card>
                      <Card.Body>
                        <div className="d-flex justify-content-between align-items-start mb-2">
                          <div><h6 className="fw-semibold mb-0">{p.name}</h6><small className="text-muted">{p.sizeAcres} acres · {p.grassType || "Unknown grass"}</small></div>
                          <Button variant="link" size="sm" className="p-0" onClick={() => { deletePasture(p.id); toast.success("Pasture deleted"); }}><Trash2 size={14} className="text-danger" /></Button>
                        </div>
                        <div className="d-flex gap-1 flex-wrap">
                          <Badge className={`${conditionBadge[p.condition]} text-capitalize`}>{p.condition}</Badge>
                          {p.isResting && <Badge bg="light" text="dark">Resting</Badge>}
                          {p.currentHerdCount > 0 && <Badge bg="light" text="dark">{p.currentHerdCount} animals</Badge>}
                        </div>
                      </Card.Body>
                    </Card>
                  </Col>
                ))}
              </Row>
            )}
          </Tab.Pane>
          <Tab.Pane eventKey="rotations">
            <Card><Card.Body className="p-0">
              {rotations.length === 0 ? (
                <div className="p-5 text-center text-muted">No rotations scheduled.</div>
              ) : (
                <Table hover responsive className="mb-0">
                  <thead><tr><th>Pasture</th><th>Herd Group</th><th>Start</th><th>End</th><th style={{ width: 40 }}></th></tr></thead>
                  <tbody>
                    {[...rotations].sort((a, b) => a.startDate.localeCompare(b.startDate)).map((r) => (
                      <tr key={r.id}>
                        <td>{pastures.find((p) => p.id === r.pastureId)?.name || "—"}</td>
                        <td>{r.herdGroup}</td><td className="small">{r.startDate}</td><td className="small">{r.endDate}</td>
                        <td><Button variant="link" size="sm" className="p-0" onClick={() => { deleteRotation(r.id); toast.success("Rotation deleted"); }}><Trash2 size={14} className="text-danger" /></Button></td>
                      </tr>
                    ))}
                  </tbody>
                </Table>
              )}
            </Card.Body></Card>
          </Tab.Pane>
        </Tab.Content>
      </Tab.Container>

      <PastureDialog open={pastureOpen} onOpenChange={setPastureOpen} onSubmit={(d) => { addPasture(d); toast.success("Pasture added"); }} />
      <RotationDialog open={rotationOpen} onOpenChange={setRotationOpen} pastures={pastures} onSubmit={(d) => { addRotation(d); toast.success("Rotation scheduled"); }} />
    </div>
  );
}
