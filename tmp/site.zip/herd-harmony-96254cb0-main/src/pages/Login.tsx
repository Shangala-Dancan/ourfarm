import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { Card, Form, Button } from "react-bootstrap";
import { toast } from "react-toastify";
import { Tractor } from "lucide-react";

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      await login(email, password);
      toast.success("Welcome back!");
      navigate("/");
    } catch (err: any) {
      toast.error(err.message || "Login failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-wrapper">
      <Card className="auth-card shadow-sm">
        <Card.Body className="p-4">
          <div className="text-center mb-4">
            <div className="auth-icon">
              <Tractor size={24} />
            </div>
            <h4 className="fw-bold mt-2">Welcome Back</h4>
            <p className="text-muted small">Sign in to your livestock management account</p>
          </div>
          <Form onSubmit={handleSubmit}>
            <Form.Group className="mb-3">
              <Form.Label>Email</Form.Label>
              <Form.Control type="email" placeholder="you@example.com" value={email} onChange={(e) => setEmail(e.target.value)} required />
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label>Password</Form.Label>
              <Form.Control type="password" placeholder="••••••••" value={password} onChange={(e) => setPassword(e.target.value)} required />
            </Form.Group>
            <Button type="submit" className="w-100 btn-farmflow" disabled={loading}>
              {loading ? "Signing in…" : "Sign In"}
            </Button>
            <p className="text-center text-muted small mt-3">
              Don't have an account?{" "}
              <Link to="/signup" className="text-farmflow fw-medium">Sign up</Link>
            </p>
          </Form>
        </Card.Body>
      </Card>
    </div>
  );
}
