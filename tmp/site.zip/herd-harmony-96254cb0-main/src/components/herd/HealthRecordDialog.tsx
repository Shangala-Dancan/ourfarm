import { useState } from "react";
import { Modal, Form, Button } from "react-bootstrap";
import type { HealthRecord } from "@/contexts/HerdContext";

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  animalId: string;
  onSubmit: (data: Omit<HealthRecord, "id" | "farmId">) => void;
}

export function HealthRecordDialog({ open, onOpenChange, animalId, onSubmit }: Props) {
  const [form, setForm] = useState({ type: "vaccination" as HealthRecord["type"], date: new Date().toISOString().split("T")[0], description: "", notes: "" });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit({ ...form, animalId });
    onOpenChange(false);
    setForm({ type: "vaccination", date: new Date().toISOString().split("T")[0], description: "", notes: "" });
  };

  return (
    <Modal show={open} onHide={() => onOpenChange(false)} centered>
      <Modal.Header closeButton><Modal.Title>Add Health Record</Modal.Title></Modal.Header>
      <Form onSubmit={handleSubmit}>
        <Modal.Body>
          <Form.Group className="mb-3"><Form.Label>Type</Form.Label>
            <Form.Select value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value as HealthRecord["type"] })}>
              <option value="vaccination">Vaccination</option><option value="treatment">Treatment</option><option value="vet_visit">Vet Visit</option>
            </Form.Select>
          </Form.Group>
          <Form.Group className="mb-3"><Form.Label>Date</Form.Label><Form.Control type="date" required value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} /></Form.Group>
          <Form.Group className="mb-3"><Form.Label>Description *</Form.Label><Form.Control required value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} /></Form.Group>
          <Form.Group><Form.Label>Notes</Form.Label><Form.Control as="textarea" rows={2} value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} /></Form.Group>
        </Modal.Body>
        <Modal.Footer><Button variant="secondary" onClick={() => onOpenChange(false)}>Cancel</Button><Button type="submit" className="btn-farmflow">Add Record</Button></Modal.Footer>
      </Form>
    </Modal>
  );
}
