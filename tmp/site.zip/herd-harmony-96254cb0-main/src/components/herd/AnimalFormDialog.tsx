import { useState, useEffect } from "react";
import { Modal, Form, Button, Row, Col } from "react-bootstrap";
import type { Animal, AnimalGender, AnimalStatus } from "@/contexts/HerdContext";

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  animal?: Animal | null;
  onSubmit: (data: Omit<Animal, "id" | "farmId">) => void;
}

const defaultForm = {
  tagNumber: "", name: "", breed: "", gender: "female" as AnimalGender,
  dateOfBirth: "", acquisitionDate: "", status: "active" as AnimalStatus, notes: "",
};

export function AnimalFormDialog({ open, onOpenChange, animal, onSubmit }: Props) {
  const [form, setForm] = useState(defaultForm);

  useEffect(() => {
    if (animal) {
      setForm({ tagNumber: animal.tagNumber, name: animal.name, breed: animal.breed, gender: animal.gender, dateOfBirth: animal.dateOfBirth, acquisitionDate: animal.acquisitionDate, status: animal.status, notes: animal.notes });
    } else {
      setForm(defaultForm);
    }
  }, [animal, open]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(form);
    onOpenChange(false);
  };

  return (
    <Modal show={open} onHide={() => onOpenChange(false)} centered>
      <Modal.Header closeButton>
        <Modal.Title>{animal ? "Edit Animal" : "Add Animal"}</Modal.Title>
      </Modal.Header>
      <Form onSubmit={handleSubmit}>
        <Modal.Body>
          <Row className="g-3 mb-3">
            <Col sm={6}><Form.Group><Form.Label>Tag Number *</Form.Label><Form.Control required value={form.tagNumber} onChange={(e) => setForm({ ...form, tagNumber: e.target.value })} /></Form.Group></Col>
            <Col sm={6}><Form.Group><Form.Label>Name</Form.Label><Form.Control value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></Form.Group></Col>
          </Row>
          <Row className="g-3 mb-3">
            <Col sm={6}><Form.Group><Form.Label>Breed</Form.Label><Form.Control value={form.breed} onChange={(e) => setForm({ ...form, breed: e.target.value })} /></Form.Group></Col>
            <Col sm={6}><Form.Group><Form.Label>Gender</Form.Label>
              <Form.Select value={form.gender} onChange={(e) => setForm({ ...form, gender: e.target.value as AnimalGender })}>
                <option value="female">Female</option><option value="male">Male</option>
              </Form.Select>
            </Form.Group></Col>
          </Row>
          <Row className="g-3 mb-3">
            <Col sm={6}><Form.Group><Form.Label>Date of Birth</Form.Label><Form.Control type="date" value={form.dateOfBirth} onChange={(e) => setForm({ ...form, dateOfBirth: e.target.value })} /></Form.Group></Col>
            <Col sm={6}><Form.Group><Form.Label>Acquisition Date</Form.Label><Form.Control type="date" value={form.acquisitionDate} onChange={(e) => setForm({ ...form, acquisitionDate: e.target.value })} /></Form.Group></Col>
          </Row>
          <Form.Group className="mb-3"><Form.Label>Status</Form.Label>
            <Form.Select value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value as AnimalStatus })}>
              <option value="active">Active</option><option value="sold">Sold</option><option value="deceased">Deceased</option>
            </Form.Select>
          </Form.Group>
          <Form.Group><Form.Label>Notes</Form.Label><Form.Control as="textarea" rows={2} value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} /></Form.Group>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button type="submit" className="btn-farmflow">{animal ? "Save Changes" : "Add Animal"}</Button>
        </Modal.Footer>
      </Form>
    </Modal>
  );
}
