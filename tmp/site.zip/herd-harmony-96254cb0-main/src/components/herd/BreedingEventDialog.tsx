import { useState } from "react";
import { Modal, Form, Button } from "react-bootstrap";
import type { BreedingEvent } from "@/contexts/HerdContext";

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  animalId: string;
  onSubmit: (data: Omit<BreedingEvent, "id" | "farmId">) => void;
}

export function BreedingEventDialog({ open, onOpenChange, animalId, onSubmit }: Props) {
  const [form, setForm] = useState({ breedingDate: "", expectedCalvingDate: "", actualCalvingDate: "", outcome: "pending" as BreedingEvent["outcome"], notes: "" });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit({ ...form, animalId });
    onOpenChange(false);
    setForm({ breedingDate: "", expectedCalvingDate: "", actualCalvingDate: "", outcome: "pending", notes: "" });
  };

  return (
    <Modal show={open} onHide={() => onOpenChange(false)} centered>
      <Modal.Header closeButton><Modal.Title>Add Breeding Event</Modal.Title></Modal.Header>
      <Form onSubmit={handleSubmit}>
        <Modal.Body>
          <Form.Group className="mb-3"><Form.Label>Breeding Date *</Form.Label><Form.Control type="date" required value={form.breedingDate} onChange={(e) => setForm({ ...form, breedingDate: e.target.value })} /></Form.Group>
          <Form.Group className="mb-3"><Form.Label>Expected Calving Date</Form.Label><Form.Control type="date" value={form.expectedCalvingDate} onChange={(e) => setForm({ ...form, expectedCalvingDate: e.target.value })} /></Form.Group>
          <Form.Group className="mb-3"><Form.Label>Actual Calving Date</Form.Label><Form.Control type="date" value={form.actualCalvingDate} onChange={(e) => setForm({ ...form, actualCalvingDate: e.target.value })} /></Form.Group>
          <Form.Group className="mb-3"><Form.Label>Outcome</Form.Label>
            <Form.Select value={form.outcome} onChange={(e) => setForm({ ...form, outcome: e.target.value as BreedingEvent["outcome"] })}>
              <option value="pending">Pending</option><option value="successful">Successful</option><option value="unsuccessful">Unsuccessful</option>
            </Form.Select>
          </Form.Group>
          <Form.Group><Form.Label>Notes</Form.Label><Form.Control as="textarea" rows={2} value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} /></Form.Group>
        </Modal.Body>
        <Modal.Footer><Button variant="secondary" onClick={() => onOpenChange(false)}>Cancel</Button><Button type="submit" className="btn-farmflow">Add Event</Button></Modal.Footer>
      </Form>
    </Modal>
  );
}
