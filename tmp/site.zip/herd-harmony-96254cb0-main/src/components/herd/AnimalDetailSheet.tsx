import { useState } from "react";
import { Offcanvas, Tab, Nav, Table, Badge, Button, Card } from "react-bootstrap";
import { Plus, Trash2, Pencil } from "lucide-react";
import { useHerd, type Animal } from "@/contexts/HerdContext";
import { HealthRecordDialog } from "./HealthRecordDialog";
import { BreedingEventDialog } from "./BreedingEventDialog";

interface Props {
  animal: Animal | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onEdit: (animal: Animal) => void;
}

const statusBadge: Record<string, string> = { active: "badge-active", sold: "badge-sold", deceased: "badge-deceased" };

export function AnimalDetailSheet({ animal, open, onOpenChange, onEdit }: Props) {
  const { healthRecords, breedingEvents, addHealthRecord, deleteHealthRecord, addBreedingEvent, deleteBreedingEvent } = useHerd();
  const [healthOpen, setHealthOpen] = useState(false);
  const [breedingOpen, setBreedingOpen] = useState(false);

  if (!animal) return null;

  const animalHealth = healthRecords.filter((h) => h.animalId === animal.id);
  const animalBreeding = breedingEvents.filter((b) => b.animalId === animal.id);

  return (
    <>
      <Offcanvas show={open} onHide={() => onOpenChange(false)} placement="end" style={{ maxWidth: 500 }}>
        <Offcanvas.Header closeButton>
          <Offcanvas.Title>
            <div className="d-flex align-items-center gap-2">
              <span className="h5 mb-0">{animal.name || animal.tagNumber}</span>
              <Badge className={statusBadge[animal.status]}>{animal.status}</Badge>
            </div>
            <small className="text-muted d-block mt-1">Tag: {animal.tagNumber} · {animal.breed || "Unknown breed"} · {animal.gender}</small>
          </Offcanvas.Title>
        </Offcanvas.Header>
        <Offcanvas.Body>
          <Card className="mb-3">
            <Card.Body>
              <div className="row small">
                <div className="col-6 mb-2"><span className="text-muted">Date of Birth:</span><br />{animal.dateOfBirth || "—"}</div>
                <div className="col-6 mb-2"><span className="text-muted">Acquired:</span><br />{animal.acquisitionDate || "—"}</div>
                {animal.notes && <div className="col-12"><span className="text-muted">Notes:</span><br />{animal.notes}</div>}
              </div>
            </Card.Body>
          </Card>

          <Button variant="outline-secondary" size="sm" className="mb-3" onClick={() => { onOpenChange(false); onEdit(animal); }}>
            <Pencil size={14} className="me-1" /> Edit
          </Button>

          <Tab.Container defaultActiveKey="health">
            <Nav variant="tabs" className="mb-3">
              <Nav.Item><Nav.Link eventKey="health">Health ({animalHealth.length})</Nav.Link></Nav.Item>
              <Nav.Item><Nav.Link eventKey="breeding">Breeding ({animalBreeding.length})</Nav.Link></Nav.Item>
            </Nav>
            <Tab.Content>
              <Tab.Pane eventKey="health">
                <Button size="sm" className="btn-farmflow mb-2" onClick={() => setHealthOpen(true)}>
                  <Plus size={14} className="me-1" /> Add Record
                </Button>
                {animalHealth.length === 0 ? (
                  <p className="text-muted small">No health records yet.</p>
                ) : (
                  <Table hover responsive size="sm">
                    <thead><tr><th>Date</th><th>Type</th><th>Description</th><th style={{ width: 40 }}></th></tr></thead>
                    <tbody>
                      {animalHealth.sort((a, b) => b.date.localeCompare(a.date)).map((r) => (
                        <tr key={r.id}>
                          <td className="small">{r.date}</td>
                          <td><Badge bg="light" text="dark" className="text-capitalize">{r.type.replace("_", " ")}</Badge></td>
                          <td className="small">{r.description}</td>
                          <td><Button variant="link" size="sm" className="p-0" onClick={() => deleteHealthRecord(r.id)}><Trash2 size={14} className="text-danger" /></Button></td>
                        </tr>
                      ))}
                    </tbody>
                  </Table>
                )}
              </Tab.Pane>
              <Tab.Pane eventKey="breeding">
                <Button size="sm" className="btn-farmflow mb-2" onClick={() => setBreedingOpen(true)}>
                  <Plus size={14} className="me-1" /> Add Event
                </Button>
                {animalBreeding.length === 0 ? (
                  <p className="text-muted small">No breeding events yet.</p>
                ) : (
                  <Table hover responsive size="sm">
                    <thead><tr><th>Bred</th><th>Expected</th><th>Outcome</th><th style={{ width: 40 }}></th></tr></thead>
                    <tbody>
                      {animalBreeding.sort((a, b) => b.breedingDate.localeCompare(a.breedingDate)).map((e) => (
                        <tr key={e.id}>
                          <td className="small">{e.breedingDate}</td>
                          <td className="small">{e.expectedCalvingDate || "—"}</td>
                          <td><Badge bg={e.outcome === "successful" ? "success" : "secondary"} className="text-capitalize">{e.outcome}</Badge></td>
                          <td><Button variant="link" size="sm" className="p-0" onClick={() => deleteBreedingEvent(e.id)}><Trash2 size={14} className="text-danger" /></Button></td>
                        </tr>
                      ))}
                    </tbody>
                  </Table>
                )}
              </Tab.Pane>
            </Tab.Content>
          </Tab.Container>
        </Offcanvas.Body>
      </Offcanvas>

      <HealthRecordDialog open={healthOpen} onOpenChange={setHealthOpen} animalId={animal.id} onSubmit={addHealthRecord} />
      <BreedingEventDialog open={breedingOpen} onOpenChange={setBreedingOpen} animalId={animal.id} onSubmit={addBreedingEvent} />
    </>
  );
}
