import { Outlet } from "react-router-dom";
import { useState } from "react";
import { AppSidebar } from "./AppSidebar";
import { useAuth } from "@/contexts/AuthContext";
import { Bell, Menu } from "lucide-react";

export function AppLayout() {
  const { user, currentFarm } = useAuth();
  const [sidebarOpen, setSidebarOpen] = useState(true);

  return (
    <div className="d-flex">
      <AppSidebar open={sidebarOpen} onToggle={() => setSidebarOpen(!sidebarOpen)} />
      <div className={`main-content ${!sidebarOpen ? 'expanded' : ''}`}>
        <header className="main-header">
          <div className="d-flex align-items-center gap-2">
            <button className="btn btn-sm btn-light" onClick={() => setSidebarOpen(!sidebarOpen)}>
              <Menu size={18} />
            </button>
            <span className="text-muted small">
              {currentFarm?.name || "No farm selected"}
            </span>
          </div>
          <div className="d-flex align-items-center gap-2">
            <button className="btn btn-sm btn-light position-relative">
              <Bell size={16} />
            </button>
            <div className="user-avatar">
              {user?.name?.charAt(0).toUpperCase() || "U"}
            </div>
          </div>
        </header>
        <div className="page-content">
          <Outlet />
        </div>
      </div>
    </div>
  );
}
