import { useAuth } from "@/contexts/AuthContext";
import { NavLink } from "react-router-dom";
import { Form } from "react-bootstrap";
import {
  LayoutDashboard,
  Bug as CowIcon,
  Milk,
  TreePine,
  ArrowLeftRight,
  DollarSign,
  LogOut,
  Tractor,
} from "lucide-react";

const navItems = [
  { to: "/", label: "Dashboard", icon: LayoutDashboard },
  { to: "/herd", label: "Herd Management", icon: CowIcon },
  { to: "/milk", label: "Milk Production", icon: Milk },
  { to: "/pastures", label: "Pastures", icon: TreePine },
  { to: "/movements", label: "Movements", icon: ArrowLeftRight },
  { to: "/finances", label: "Finances", icon: DollarSign },
];

interface Props {
  open: boolean;
  onToggle: () => void;
}

export function AppSidebar({ open }: Props) {
  const { user, farms, currentFarm, setCurrentFarm, logout } = useAuth();

  return (
    <div className={`sidebar ${open ? '' : 'collapsed'}`}>
      <div className="sidebar-header">
        <div className="d-flex align-items-center gap-2 mb-2">
          <div className="d-flex align-items-center justify-content-center rounded bg-farmflow" style={{ width: 32, height: 32 }}>
            <Tractor size={16} color="white" />
          </div>
          <span className="fw-bold fs-5">FarmFlow</span>
        </div>
        {farms.length > 0 && (
          <Form.Select
            size="sm"
            value={currentFarm?.id || ""}
            onChange={(e) => setCurrentFarm(e.target.value)}
          >
            {farms.map((farm) => (
              <option key={farm.id} value={farm.id}>{farm.name}</option>
            ))}
          </Form.Select>
        )}
      </div>

      <div className="sidebar-content">
        <p className="text-muted small text-uppercase fw-semibold px-2 mb-2 mt-2" style={{ fontSize: '0.7rem', letterSpacing: '0.05em' }}>Menu</p>
        <nav className="sidebar-nav">
          {navItems.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.to === "/"}
              className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}
            >
              <item.icon size={16} />
              {item.label}
            </NavLink>
          ))}
        </nav>
      </div>

      <div className="sidebar-footer">
        <div className="d-flex align-items-center justify-content-between">
          <div className="text-truncate me-2">
            <div className="small fw-medium">{user?.name}</div>
            <div className="text-muted text-capitalize" style={{ fontSize: '0.75rem' }}>{user?.role}</div>
          </div>
          <button onClick={logout} className="btn btn-sm btn-light" title="Sign out">
            <LogOut size={16} />
          </button>
        </div>
      </div>
    </div>
  );
}
